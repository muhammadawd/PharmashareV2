<div class="modal" id="comment-images-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <br>
            </div>
            <div class="modal-body text-center">
                <div class="row">
                    <div class="col-md-7">
                        <div class="wrapper">
                            <div class="slider" id="SlidePost">

                            </div>
                            <nav class="slider-nav">
                                <ul>
                                    <li class="arrow">
                                        <a class="previous">
                                          <span>
                                            <i class="ion-arrow-left-c"></i>
                                          </span>
                                        </a>
                                    </li>
                                    <li class="arrow">
                                        <a class="next">
                                          <span>
                                            <i class="ion-arrow-right-c"></i>
                                          </span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-5 direction" id="CommetsPost" style="overflow-y: auto;height: 500px;">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>