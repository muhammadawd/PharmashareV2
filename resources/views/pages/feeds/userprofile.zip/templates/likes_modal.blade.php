<div class="modal fade" id="likes-modal-sm" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content" style="background: linear-gradient(50deg, #3f4bb3, #7e56c4)">
            <div class="modal-body text-center direction">
                <div class="media-body direction" id="modal_likes_content">

                </div>
            </div>
        </div>
    </div>
</div>